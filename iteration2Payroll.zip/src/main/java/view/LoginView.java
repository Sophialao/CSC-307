package view;

public class LoginView {
}
