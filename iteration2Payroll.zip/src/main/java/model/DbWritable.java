package model;

public interface DbWritable {

    void write();
    void readFields(String[] args);
}
