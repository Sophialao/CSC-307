package model;

import java.util.Date;


public class Report {
    private Date date;
    

    public Report() {

    }
}